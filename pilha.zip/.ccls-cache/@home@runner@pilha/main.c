#include <stdio.h>
#include <stdlib.h>
#include "pilha_encadeada.c"

int main() {
    Pilha *p = criar_pilha();

    printf("Pilha vazia? %d\n", pilha_vazia(p));
    printf("Tamanho da pilha: %d\n", tamanho_pilha(p));

    push(p, 10);
    push(p, 20);
    push(p, 30);

    printf("Pilha vazia? %d\n", pilha_vazia(p));
    printf("Tamanho da pilha: %d\n", tamanho_pilha(p));
    printf("Topo da pilha: %d\n", topo_pilha(p));

    pop(p);

    printf("Pilha vazia? %d\n", pilha_vazia(p));
    printf("Tamanho da pilha: %d\n", tamanho_pilha(p));
    printf("Topo da pilha: %d\n", topo_pilha(p));

    return 0;
}